package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;

public class IgrajKvizAkt extends AppCompatActivity implements InformacijeFrag.OnFragmentInfInteractionListener,PitanjeFrag.OnFragmentInteractionListener{
    private InformacijeFrag im_fragment = new InformacijeFrag();
    private PitanjeFrag pm_fragment = new PitanjeFrag();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_igrajkviz);
        Configuration config = getResources().getConfiguration();
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction =
                fragmentManager.beginTransaction();

            fragmentTransaction.replace(R.id.informacije_place, im_fragment);
            fragmentTransaction.commit();
        FragmentTransaction fragmentTransaction2 =
                fragmentManager.beginTransaction();

            fragmentTransaction2.replace(R.id.pitanje_place, pm_fragment);
            fragmentTransaction2.commit();
    }

    @Override
    public void onFragmentInteraction(Kviz kviz) {
       im_fragment.changeInf();
    }

    @Override
    public void onFragmentInfInteraction() {
        Intent intent = new Intent();
        setResult(4,intent);
        finish();
    }
}
