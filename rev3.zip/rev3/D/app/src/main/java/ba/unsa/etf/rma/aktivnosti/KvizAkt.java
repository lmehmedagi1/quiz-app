package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;


import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.CustomListKvizAdapter;
import ba.unsa.etf.rma.klase.CustomSpinnerAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.PomocnaBaza;
import ba.unsa.etf.rma.klase.ShareIgraj;

import static ba.unsa.etf.rma.aktivnosti.DodajKvizAkt.convertStreamToString;
import static ba.unsa.etf.rma.klase.PomocnaBaza.kategorije;
import static ba.unsa.etf.rma.klase.PomocnaBaza.kvizovi;
import static ba.unsa.etf.rma.klase.PomocnaBaza.spAdapter;
import static ba.unsa.etf.rma.klase.ShareIgraj.igraj_kviz;
import static ba.unsa.etf.rma.klase.ShareKviz.sharePitanja;
import static ba.unsa.etf.rma.klase.ShareKviz.uredi;


public class KvizAkt extends AppCompatActivity {
    public class VratiSveKategorijeTask extends AsyncTask<String,Void,Void>{

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            String TOKEN="";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                TOKEN = credentials.getAccessToken();
                Log.d("EMINA", TOKEN);
                //DOHVATITI ID DOKUMENTA PITANJA KOJA SU SADRZANA U KVIZU KOJI SE TREBA SPASIT U BAZU-RJESENO
                String url = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Kategorije?access_token=" + TOKEN;
                URL urlP;

                urlP = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) urlP.openConnection();
                InputStream iS = new BufferedInputStream(conn.getInputStream());
                String result = convertStreamToString(iS);
                JSONObject o = null;
                o = new JSONObject(result);
                JSONArray dok = o.getJSONArray("documents");

                for (int e = 0; e < dok.length(); e++) {
                    Kategorija kat=new Kategorija();
                    JSONObject name1 = null;
                    name1 = dok.getJSONObject(e);
                    String idK = name1.getString("name");
                    idK = idK.substring(65);

                    JSONObject kategorija = name1.getJSONObject("fields");
                    String nazivK = kategorija.getJSONObject("naziv").getString("stringValue");
                    String idIkon=kategorija.getJSONObject("idIkonice").getString("integerValue");
                    kat.setNaziv(nazivK);
                    kat.setIdBaza(idK);
                    kat.setId(idIkon);
                    kategorije.add(kat);

                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public class VratiSvaPitanjaTask extends  AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials ;
            String TOKEN="";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                TOKEN = credentials.getAccessToken();
                Log.d("EMINA", TOKEN);
                //DOHVATITI ID DOKUMENTA PITANJA KOJA SU SADRZANA U KVIZU KOJI SE TREBA SPASIT U BAZU-RJESENO
                String url = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Pitanja?access_token=" + TOKEN;
                URL urlP;

                urlP = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) urlP.openConnection();
                InputStream iS = new BufferedInputStream(conn.getInputStream());
                String result = convertStreamToString(iS);
                JSONObject o = null;
                o = new JSONObject(result);
                JSONArray dok = o.getJSONArray("documents");

                for (int e = 0; e < dok.length(); e++) {
                    Pitanje pit;
                    JSONObject name1 = null;
                    name1 = dok.getJSONObject(e);
                    String idP = name1.getString("name");
                    idP = idP.substring(62);

                        JSONObject pitanje = name1.getJSONObject("fields");
                        String nazivP = pitanje.getJSONObject("naziv").getString("stringValue");
                        int indexTacnog = Integer.parseInt(pitanje.getJSONObject("indexTacnog").getString("integerValue"));
                        ArrayList<String> odgovori = new ArrayList<String>();
                        JSONArray nizOdg = pitanje.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                        for (int r = 0; r < nizOdg.length(); r++) {
                            odgovori.add(nizOdg.getJSONObject(r).getString("stringValue"));
                        }
                        pit = new Pitanje(nazivP, nazivP, odgovori, odgovori.get(indexTacnog));
                        pit.setId(idP);
                        pitanja.add(pit);

                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class OdabranaKatTask extends AsyncTask<String, Integer, Void> {

        @Override
        protected Void doInBackground(String... strings) {

            return null;
        }
    }

    private class SviTask extends AsyncTask<String, Integer, Void> {
        @Override
        protected void onPreExecute() {
            new VratiSvaPitanjaTask().execute("Spirala3");
            new VratiSveKategorijeTask().execute("Spirala3");
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            odabrana_kat_kvizovi.add(dodaj);
            adapterLista.notifyDataSetChanged();
            spAdapter.notifyDataSetChanged();
            super.onPostExecute(aVoid);
        }

        @Override
        protected Void doInBackground(String... strings) {

            GoogleCredential credentials ;
            String TOKEN="";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);


                credentials = GoogleCredential.fromStream(is).
                        createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));


                credentials.refreshToken();

                TOKEN = credentials.getAccessToken();
                Log.d("EMINA", TOKEN);
                //DOHVATITI ID DOKUMENT TRENUTNOG KVIZA
                String url2 = "https://firestore.googleapis.com/v1/projects/spirala3-167cb/databases/(default)/documents/Kvizovi?access_token=" + TOKEN;
                URL url3;

                url3 = new URL(url2);
                HttpURLConnection urlConnection = (HttpURLConnection) url3.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rez = convertStreamToString(in);
                JSONObject j = null;
                j = new JSONObject(rez);
                JSONArray items = j.getJSONArray("documents");

                for (int i = 0; i < items.length(); i++) {
                    ArrayList<Pitanje> pit=new ArrayList<>();
                    JSONObject name = null;
                    name = items.getJSONObject(i);
                    String id = name.getString("name");
                    id = id.substring(62);
                    JSONObject kviz = name.getJSONObject("fields");
                    String naziv = kviz.getJSONObject("naziv").getString("stringValue");
                    JSONArray nizPit = kviz.getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");
                    for (int r = 0; r < nizPit.length(); r++){
                        for(Pitanje p: pitanja) {
                            if( p.getId().equals(nizPit.getJSONObject(r).getString("stringValue")))
                                pit.add(p);
                        }
                    }
                    Kviz k= new Kviz();
                    String katID = kviz.getJSONObject("idKategorije").getString("stringValue");
                    for(Kategorija v: kategorije){
                        if(v.getIdBaza().equals(katID)){
                            k.setKategorija(v);
                            break;
                        }
                    }

                    k.setPitanja(pit);
                    k.setNaziv(naziv);

                    odabrana_kat_kvizovi.add(k);


                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private Kategorija kat0=new Kategorija();
    private Kviz dodaj= new Kviz();
    private ListView lista;
    private Spinner spinner;
    private  KvizAkt CustomListView = null;
    private Resources res;
    private  ArrayList<Kviz> odabrana_kat_kvizovi=new ArrayList<>();
    private ArrayList<Pitanje> pitanja=new ArrayList<Pitanje>();
    private Kategorija selectedKat;

    private CustomListKvizAdapter adapterLista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(ba.unsa.etf.rma.R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        kvizovi=new ArrayList<>();

        lista=(ListView) findViewById(R.id.lvKvizovi);
        spinner=(Spinner) findViewById(R.id.spPostojeceKategorije);
        res=getResources();




        CustomListView = this;

        adapterLista = new CustomListKvizAdapter( CustomListView, odabrana_kat_kvizovi, res );
        lista.setAdapter( adapterLista );



        spAdapter= new CustomSpinnerAdapter(this, PomocnaBaza.kategorije);
        spinner.setAdapter(spAdapter);

        initLists();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                selectedKat= (Kategorija) spinner.getSelectedItem();
                Kategorija clikedItem=(Kategorija) parent.getItemAtPosition(pos);
                String clickesKatNaziv=clikedItem.getNaziv();
                Toast.makeText(KvizAkt.this,"Odabrali ste: "+clickesKatNaziv, Toast.LENGTH_SHORT).show();


                odabrana_kat_kvizovi.removeAll(odabrana_kat_kvizovi);
                if(!clikedItem.getNaziv().equals("SVI")) {
                    new OdabranaKatTask().execute("Spirala3");
                    for(Kviz h: kvizovi){
                        if(h.getKategorija().getNaziv().equals(clickesKatNaziv))
                            odabrana_kat_kvizovi.add(h);
                            adapterLista.notifyDataSetChanged();
                    }
                } else{

                    kategorije.removeAll(kategorije);
                    new SviTask().execute("Spirala3");

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           int pos, long arg3) {
                //Kviz clikedItem=(Kviz) parent.getItemAtPosition(pos);

                if(odabrana_kat_kvizovi.size()!=0){
                    String clickedKvizNaziv=odabrana_kat_kvizovi.get(pos).getNaziv();
                    if(clickedKvizNaziv.equals("Dodaj Kviz")) {
                        Intent intent = new Intent(KvizAkt.this, DodajKvizAkt.class);
                        startActivityForResult(intent,1);
                    }else {
                        Intent intent = new Intent(KvizAkt.this, DodajKvizAkt.class);
                        startActivityForResult(intent,1);
                        uredi = odabrana_kat_kvizovi.get(pos);
                    }
                }


               return true;
            }
        });
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
              String clickedKvizNaziv=odabrana_kat_kvizovi.get(pos).getNaziv();
                if(!clickedKvizNaziv.equals("Dodaj Kviz")) {
                    igraj_kviz = odabrana_kat_kvizovi.get(pos);
                    Intent intent = new Intent(KvizAkt.this, IgrajKvizAkt.class);
                    startActivityForResult(intent, 4);
                }

            }
        });



    }

    private void initLists() {




        kat0.setId("10");
        kat0.setNaziv("SVI");

        dodaj.setKategorija(kat0);
        dodaj.setNaziv("Dodaj Kviz");
        //int vel= odabrana_kat_kvizovi.size();
        odabrana_kat_kvizovi.removeAll(odabrana_kat_kvizovi);
        kategorije.removeAll(kategorije);
        new SviTask().execute("Spirala3");

    }
   @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
       /* // Check which request we're responding to
        adapterLista.notifyDataSetChanged();
        if (requestCode == 1) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {
                ;
            }
        }*/
       sharePitanja.removeAll(sharePitanja);
       odabrana_kat_kvizovi.removeAll(odabrana_kat_kvizovi);
       kategorije.removeAll(kategorije);
       new SviTask().execute("Spirala3");
    }


}
