package ba.unsa.etf.rma.klase;

import java.util.ArrayList;

public class PomocnaBaza {
    public static volatile ArrayList<Kategorija> kategorije=new ArrayList<>();
    public static volatile ArrayList<Kviz> kvizovi ;
    public static  volatile CustomSpinnerAdapter spAdapter;



}
