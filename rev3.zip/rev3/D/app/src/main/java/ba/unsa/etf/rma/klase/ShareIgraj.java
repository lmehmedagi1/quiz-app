package ba.unsa.etf.rma.klase;

public class ShareIgraj {
    public static int broj_tacnih=0;
    public static Kviz igraj_kviz;
    public static int broj_preostalih=0;
    public static int broj=0;

}
