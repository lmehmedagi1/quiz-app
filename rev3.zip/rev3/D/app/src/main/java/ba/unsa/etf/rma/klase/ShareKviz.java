package ba.unsa.etf.rma.klase;

import java.util.ArrayList;

public class ShareKviz {
    public static volatile ArrayList<Pitanje> sharePitanja=new ArrayList<>();
    public static volatile Pitanje trenutno;
    public static volatile Kviz uredi;
}
