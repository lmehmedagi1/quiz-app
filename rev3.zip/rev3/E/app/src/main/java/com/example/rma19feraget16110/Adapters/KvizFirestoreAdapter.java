package com.example.rma19feraget16110.Adapters;

public class KvizFirestoreAdapter{
}
