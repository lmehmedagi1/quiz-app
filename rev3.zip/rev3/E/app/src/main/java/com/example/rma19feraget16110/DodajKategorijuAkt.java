package com.example.rma19feraget16110;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.rma19feraget16110.Model.Kategorija;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import java.util.ArrayList;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {
    ArrayList<Kategorija> kategorija = new ArrayList<>();
    EditText ikonaKategorije, nazivKategorije;
    Button dodajKategoriju, dodajIkonu;
    private com.maltaisn.icondialog.Icon[] selectedIcons;
    IconDialog iconDialog=new IconDialog();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);
        Intent i = getIntent();
        Bundle b = i.getExtras();
        kategorija = (ArrayList<Kategorija>) b.getSerializable("kategorije");
        ikonaKategorije = findViewById(R.id.etIkona);
        dodajKategoriju = findViewById(R.id.btnDodajKategoriju);
        nazivKategorije = findViewById(R.id.etNaziv);
        dodajIkonu = findViewById(R.id.btnDodajIkonu);
        ikonaKategorije.setEnabled(false);
        nazivKategorije.getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);

        dodajKategoriju.setOnClickListener(v -> {
            if (!checkForCategory(kategorija) && !validateField(nazivKategorije)) {
                Kategorija k = new Kategorija(nazivKategorije.getText().toString(), ikonaKategorije.toString());
                Intent i1 = new Intent();
                i1.putExtra("kat", k);
                setResult(Activity.RESULT_OK, i1);
                finish();

            } else {
                nazivKategorije.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
                Toast.makeText(getApplicationContext(), "Unesena kategorija vec postoji", Toast.LENGTH_SHORT).show();
            }
        });

        dodajIkonu.setOnClickListener(v -> {
            iconDialog.setSelectedIcons(selectedIcons);
            iconDialog.show(getSupportFragmentManager(),"icon_dialog");
        });
    }

    public boolean checkForCategory(ArrayList<Kategorija> kategorija) {
        for (Kategorija k : kategorija) {
            if (nazivKategorije.getText().toString().toLowerCase().equals(k.getNaziv().toLowerCase()))
                return true;
        }
        return false;
    }

    public boolean validateField(EditText editText) {
        String unos = editText.getText().toString();
        if (TextUtils.isEmpty(unos)) {
            editText.setError("The item cannot be empty");
            return true;
        }
        return false;
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 4 && resultCode == RESULT_OK) {
            Uri returnUri = data.getData();
            try {
                slika = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), returnUri);
                slika = Bitmap.createScaledBitmap(slika, 300, 300, false);
                //ikonaKategorije.setText(slika.getGenerationId());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }*/

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons=icons;
        ikonaKategorije.setText(idOfIcon(selectedIcons.toString()));
    }

    public String idOfIcon(String name){
        String id="";
        id=name.substring(name.indexOf('@')+1,name.indexOf('@')+8);
        return id;
    }
}
