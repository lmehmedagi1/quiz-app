package com.example.rma19feraget16110.Fragments;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.rma19feraget16110.Model.Kviz;
import com.example.rma19feraget16110.R;

import java.util.ArrayList;

public class PitanjeFrag extends Fragment {
    private OnItemClick onItemClick;
    ArrayList<String> odgovori = new ArrayList<>();
    private ViewPager viewPager;
    private Handler handler = new Handler();
    ArrayAdapter<String> odgovoriAdapter;
    TextView tekstPitanja;
    ListView listaOdgovora;
    Kviz kviz;
    Integer count = 0;
    Integer numberOfClicks = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View iv = inflater.inflate(R.layout.activity_pitanje_frag, container, false);
        return iv;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getArguments() != null && getArguments().containsKey("kviz"))
            kviz = (Kviz) getArguments().getSerializable("kviz");
        odgovori.addAll(kviz.getPitanja().get(0).getOdgovori());
        tekstPitanja = getView().findViewById(R.id.tekstPitanja);
        listaOdgovora = getView().findViewById(R.id.idodgovoriPitanja);
        tekstPitanja.setText(kviz.getPitanja().get(0).getTekstPitanja());
        odgovoriAdapter = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, odgovori);
        listaOdgovora.setAdapter(odgovoriAdapter);
        try {
            onItemClick = (OnItemClick) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + "Treba implementirat OnItemClick");
        }

        listaOdgovora.setOnItemClickListener((parent, view, position, id) -> {
            Integer corectAnswer;
            numberOfClicks++;
            Boolean trueAnswer;
            if (kviz.getPitanja().get(count).getTacan().equals(kviz.getPitanja().get(count).getOdgovori().get(position))) {
                listaOdgovora.getChildAt(position).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.green));
                trueAnswer = true;
            } else {
                corectAnswer = kviz.getPitanja().get(count).getOdgovori().indexOf(kviz.getPitanja().get(count).getTacan());
                listaOdgovora.getChildAt(corectAnswer).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.green));
                listaOdgovora.getChildAt(position).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.red));
                trueAnswer = false;
            }
            onItemClick.onItemClicked(count, trueAnswer);
            handler.postDelayed(() -> {
                refreshFragment();
            }, 2000);

            count++;
        });
    }

    public interface OnItemClick {
        void onItemClicked(int count, Boolean trueAnswer);
    }

    @Override
    public void onDetach() {
        onItemClick = null;
        super.onDetach();
    }

    private void refreshFragment() {
        for (int i = 0; i < kviz.getPitanja().get(count - 1).getOdgovori().size(); i++) {
            listaOdgovora.getChildAt(i).setBackgroundColor(Color.TRANSPARENT);
        }

        if (kviz.getPitanja().size() == numberOfClicks || kviz.getPitanja().get(numberOfClicks).getNaziv().equals("Dodaj pitanje")) {
            tekstPitanja.setText("Kviz je zavrsen!");
            odgovoriAdapter.clear();
            AlertDialog.Builder adb = new AlertDialog.Builder(getContext());
            LayoutInflater li =LayoutInflater.from(getContext());
            View promptsView =li.inflate(R.layout.prompts,null);
            adb.setView(promptsView);
            adb.setTitle("Rang lista");
            adb.setNegativeButton("Cancel",null);
            adb.setPositiveButton("OK", (dialog, which) -> {

            });
            adb.show();
        } else {
            odgovoriAdapter.clear();
            odgovori.addAll(kviz.getPitanja().get(count).getOdgovori());
            tekstPitanja.setText(kviz.getPitanja().get(count).getTekstPitanja());
            odgovoriAdapter.notifyDataSetChanged();
        }
    }

}


