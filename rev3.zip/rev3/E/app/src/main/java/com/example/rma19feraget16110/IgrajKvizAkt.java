package com.example.rma19feraget16110;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.example.rma19feraget16110.Fragments.InformacijeFrag;
import com.example.rma19feraget16110.Fragments.PitanjeFrag;
import com.example.rma19feraget16110.Model.Kviz;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick {
    Kviz kviz;
    InformacijeFrag informacijeFrag;
    FragmentManager fm =getSupportFragmentManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);
        Intent i=getIntent();
        Bundle b=i.getExtras();
        kviz= (Kviz) b.getSerializable("kviz");
        //FrameLayout informacije = findViewById(R.id.informacijePlace);
        //FrameLayout pitanje = findViewById(R.id.pitanjePlace);
         informacijeFrag = (InformacijeFrag)fm.findFragmentById(R.id.informacijePlace);
        if(informacijeFrag == null){
            Bundle podaci=new Bundle();
            podaci.putSerializable("kviz",kviz);
            informacijeFrag=new InformacijeFrag();
            informacijeFrag.setArguments(podaci);
            fm.beginTransaction().replace(R.id.informacijePlace,informacijeFrag).commit();
        }
        PitanjeFrag pitanjeFrag = (PitanjeFrag)fm.findFragmentById(R.id.pitanjePlace);
        if(pitanjeFrag == null){
            Bundle podaci = new Bundle();
            podaci.putSerializable("kviz",kviz);
            pitanjeFrag = new PitanjeFrag();
            pitanjeFrag.setArguments(podaci);
            fm.beginTransaction().replace(R.id.pitanjePlace,pitanjeFrag).commit();
        }
    }

    @Override
    public void onItemClicked(int count,Boolean trueAnswer) {
        fm.findFragmentById(R.id.informacijePlace);
        informacijeFrag.updateText(count,trueAnswer);
    }
}
