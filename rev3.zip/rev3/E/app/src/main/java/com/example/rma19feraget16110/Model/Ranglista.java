package com.example.rma19feraget16110.Model;

import java.io.Serializable;
import java.util.HashMap;

public class Ranglista implements Serializable {
    private String nazivKviza ="";
    private HashMap<Integer,HashMap<String,Double>> lista;

    public Ranglista(String nazivKviza, HashMap<Integer, HashMap<String, Double>> lista) {
        this.nazivKviza = nazivKviza;
        this.lista = lista;
    }

    public String getNazivKviza() {
        return nazivKviza;
    }

    public void setNazivKviza(String nazivKviza) {
        this.nazivKviza = nazivKviza;
    }

    public HashMap<Integer, HashMap<String, Double>> getLista() {
        return lista;
    }

    public void setLista(HashMap<Integer, HashMap<String, Double>> lista) {
        this.lista = lista;
    }
}
