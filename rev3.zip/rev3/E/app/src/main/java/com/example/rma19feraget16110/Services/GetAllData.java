package com.example.rma19feraget16110.Services;

import android.content.Context;
import android.os.AsyncTask;

import com.example.rma19feraget16110.R;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class GetAllData extends AsyncTask<String,Integer, JSONObject> {
    private Context mContext;
    String token,kolekcija;
    private ReturnData pozivatelj;
    JSONObject jo;
    @Override
    protected JSONObject doInBackground(String... strings) {
        kolekcija = strings[0];
        try {
            token = getToken();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try{
            String url ="https://firestore.googleapis.com/v1/projects/spirala3-67197/databases/(default)/documents/" + kolekcija + "?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(token,"UTF-8"));
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlObj.openConnection();
            InputStream in = new BufferedInputStream(httpURLConnection.getInputStream());
            String rezultat = convertStreamToString(in);
            jo = new JSONObject(rezultat);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }


    private String getToken() throws IOException {
        InputStream is = mContext.getApplicationContext().getResources().openRawResource(R.raw.secret);
        GoogleCredential credential = GoogleCredential.fromStream(is).
                createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
        credential.refreshToken();
        return credential.getAccessToken();
    }

    public GetAllData(Context context, ReturnData p){
        mContext = context;
        pozivatelj = p;
    }

    private String convertStreamToString(InputStream in){
        BufferedReader reader=new BufferedReader(new InputStreamReader(in));
        StringBuilder sb=new StringBuilder();
        String line=null;
        try{
            while((line=reader.readLine())!=null){
                sb.append(line+"\n");
            }
        } catch (IOException e){

        }finally {
            try {
                in.close();
            }  catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }



    @Override
    protected void onPostExecute(JSONObject jsonObject) {
        super.onPostExecute(jsonObject);
        try {
            pozivatelj.returnData(jo,kolekcija);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    public interface  ReturnData{
        void returnData(JSONObject jsonObject,String kolekcija) throws JSONException;
    }

}
