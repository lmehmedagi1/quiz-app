package com.example.rma19feraget16110.Services;

import android.content.Context;
import android.os.AsyncTask;

import com.example.rma19feraget16110.Model.Ranglista;

public class SaveRangliste extends AsyncTask<String,Integer,Void> {
    private Context mContext;
    private String kolekcija,token;
    private Ranglista ranglista;
    private String imeIgraca;
    @Override
    protected Void doInBackground(String... strings) {
        kolekcija = strings[0];
        return null;
    }

    public SaveRangliste(Context context, Ranglista ranglista,String imeIgraca){
        mContext = context;
        this.ranglista = ranglista;
        this.imeIgraca = imeIgraca;
    }


    public String createRanglistu(Ranglista ranglista){
        String document = "";
        document += "{\"fileds\": {\"nazivKviza\": {\"stringValue\": \"" + ranglista.getNazivKviza() + "\"},\"lista\":{\"mapValue\":{\"fields\":{\"" +
        ranglista.getLista().keySet() + "\":{\"mapValue\":{\"fields\":{\"" + ranglista.getLista().get(imeIgraca).keySet() +
        "\":{\"doubleValue\":\"" + ranglista.getLista().get(imeIgraca);
        return document;
    }
}
