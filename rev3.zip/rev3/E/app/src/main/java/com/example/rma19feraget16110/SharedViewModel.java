package com.example.rma19feraget16110;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;

public class SharedViewModel extends AndroidViewModel {
    private MutableLiveData <CharSequence> nazivKategorije =new MutableLiveData<>();

    public SharedViewModel(@NonNull Application application) {
        super(application);
    }

    public void setText(CharSequence input){
        nazivKategorije.setValue(input);
    }

    public LiveData<CharSequence> getText(){
        return nazivKategorije;
    }
}
