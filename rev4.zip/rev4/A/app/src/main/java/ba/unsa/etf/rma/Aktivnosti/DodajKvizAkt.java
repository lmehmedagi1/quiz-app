package ba.unsa.etf.rma.Aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;

import ba.unsa.etf.rma.Klase.Kategorija;
import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.Klase.MyArrayAdapterPitanja;
import ba.unsa.etf.rma.Klase.Pitanje;
import ba.unsa.etf.rma.Klase.SpinnerAdapter;
import ba.unsa.etf.rma.R;

public class DodajKvizAkt extends AppCompatActivity {
    ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();
    ListView lvPitanja;
    ListView lvMogucaPitanja;
    ArrayList<Pitanje> pitanja = new ArrayList<>();
    MyArrayAdapterPitanja adapter1;
    MyArrayAdapterPitanja adapter2;
    Button btnDodajKviz;
    String nazivKviza;
    EditText etnazivKviza;
    Kategorija pomocnaKategorija;
    ArrayList<Kategorija> kategorije;
    Spinner spinner;
    SpinnerAdapter spinnerAdapter;
    Button btnImportKviz;
    Kviz kviz;

    public class UpdateBaze extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String surl = "https://firestore.googleapis.com/v1/projects/spirala3-49671/databases/(default)/documents/Kvizovi?access_token=" + TOKEN;
                URL url = new URL(surl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                connection.setDoOutput(true);
                String JsonOutput = "{\"fields\" : { \n \"pitanja\": { \n \"arrayValue\": { \n \"values\": [ \n { \n";
                for(int i=0; i<kviz.getPitanja().size()-1; i++) {
                    if(i!=kviz.getPitanja().size()-2)
                        JsonOutput = JsonOutput + "\"stringValue\": \"" + kviz.getPitanja().get(i).getNaziv() + "\" \n }, \n { \n";
                    else JsonOutput = JsonOutput + "\"stringValue\": \"" + kviz.getPitanja().get(i).getNaziv() + "\" \n } \n ] \n } \n }, \n";
                }
                JsonOutput = JsonOutput + "\"naziv\": { \n \"stringValue\": \" " + kviz.getNaziv() + "\" \n }, \n \"idKategorije\": {" +
                        "\n \"arrayValue\": { \n \"values\": [ \n { \n \"stringValue\": \"" + kviz.getKategorija().getNaziv() +
                        "\" \n }, \n { \n \"stringValue\": \"" + kviz.getKategorija().getId() + "\" \n } \n ] \n } \n } \n } \n }";
                try(OutputStream os = connection.getOutputStream()) {
                    byte[] input = JsonOutput.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                try(BufferedReader br = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("HELLO", response.toString());
                }

            } catch(Exception e) {
                e.printStackTrace();
            }


            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        btnDodajKviz = findViewById(R.id.btnDodajKviz);
        etnazivKviza = findViewById(R.id.etNaziv);
        spinner = findViewById(R.id.spKategorije);
        lvPitanja = findViewById(R.id.lvDodanaPitanja);
        btnImportKviz = findViewById(R.id.btnImportKviz);

        kategorije = getIntent().getParcelableArrayListExtra("kategorije");
        mogucaPitanja = getIntent().getParcelableArrayListExtra("pitanja");

        Kviz k = getIntent().getParcelableExtra("kviz");
        nazivKviza = k.getNaziv();
        pomocnaKategorija = k.getKategorija();
        pitanja = k.getPitanja();

        kategorije.add(new Kategorija("Dodaj kategoriju", "337"));
        spinnerAdapter = new SpinnerAdapter(this, kategorije);
        spinner.setAdapter(spinnerAdapter);
        spinner.setSelection(0);

        if (!pitanja.get(pitanja.size() - 1).getNaziv().equalsIgnoreCase("Dodaj pitanje"))
            pitanja.add(new Pitanje("Dodaj pitanje", "tekst", new ArrayList<String>(), "tacan"));

        try {
            for (int i = 0; i < mogucaPitanja.size(); i++) {
                for (int j = 0; j < pitanja.size(); j++) {
                    if (mogucaPitanja.get(i).getNaziv().equalsIgnoreCase(pitanja.get(j).getNaziv()))
                        mogucaPitanja.remove(i);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        adapter2 = new MyArrayAdapterPitanja(this, pitanja);
        lvPitanja.setAdapter(adapter2);
    /*    for(int i=0; i<pitanja.size(); i++) {
            if(pitanja.get(i).getNaziv().equalsIgnoreCase("Testno pitanje"))
                pitanja.remove(i);
        }*/

        if(!mogucaPitanja.isEmpty())
            adapter1 = new MyArrayAdapterPitanja(this, mogucaPitanja);
            lvMogucaPitanja.setAdapter(adapter1);


        if (!nazivKviza.equalsIgnoreCase("Dodaj kviz")) {
            etnazivKviza.setText(nazivKviza);
        }

        lvPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (pitanja.get(position).getNaziv().equalsIgnoreCase("Dodaj pitanje")) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    startActivityForResult(intent, 1);
                } else {
                    mogucaPitanja.add(pitanja.get(position));
                    adapter1 = new MyArrayAdapterPitanja(DodajKvizAkt.this, mogucaPitanja);
                    lvMogucaPitanja.setAdapter(adapter1);
                    pitanja.remove(pitanja.get(position));
                    adapter2 = new MyArrayAdapterPitanja(DodajKvizAkt.this, pitanja);
                    lvPitanja.setAdapter(adapter2);
                }
            }
        });

        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pitanja.add(pitanja.size() - 1, mogucaPitanja.get(position));
                adapter2 = new MyArrayAdapterPitanja(DodajKvizAkt.this, pitanja);
                lvPitanja.setAdapter(adapter2);
                mogucaPitanja.remove(mogucaPitanja.get(position));
                adapter1 = new MyArrayAdapterPitanja(DodajKvizAkt.this, mogucaPitanja);
                lvMogucaPitanja.setAdapter(adapter1);
            }
        });

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etnazivKviza.getText().toString().equals("")) {
                    etnazivKviza.setBackgroundColor(Color.RED);
                } else {
                    etnazivKviza.setBackgroundColor(Color.TRANSPARENT);
                    pitanja.remove(pitanja.size()-1);
                    kviz = new Kviz(etnazivKviza.getText().toString(), pitanja, pomocnaKategorija);
                    new UpdateBaze().execute();
                    Intent intent = getIntent();
                    intent.putExtra("kviz", kviz);
                    setResult(2, intent);
                    finish();
                }
            }

        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (kategorije.get(position).getNaziv().equalsIgnoreCase("Dodaj kategoriju")) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    startActivityForResult(intent, 3);
                }
                else if(!kategorije.get(position).getNaziv().equalsIgnoreCase("Svi")) {
                    pomocnaKategorija = kategorije.get(position);
                }
            }
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btnImportKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                startActivityForResult(intent, 10);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == 1) {
            Pitanje p = data.getParcelableExtra("pitanje");
            if (!p.getNaziv().equalsIgnoreCase("")) {
                pitanja.add(pitanja.size() - 1, p);
                adapter2 = new MyArrayAdapterPitanja(DodajKvizAkt.this, pitanja);
                lvPitanja.setAdapter(adapter2);
            }
        }
        if(resultCode == 3) {
            Kategorija k = data.getParcelableExtra("kategorija");
            if(!k.getId().equalsIgnoreCase("")) {
                kategorije.add(kategorije.size()-1, k);
                pomocnaKategorija = k;
                spinnerAdapter.notifyDataSetChanged();
                spinnerAdapter = new SpinnerAdapter(this, kategorije);
                spinner.setAdapter(spinnerAdapter);
                spinner.setSelection(kategorije.size()-2);

            }
        }
        if(requestCode == 10) {
            Uri u = data.getData();
            try {
                String str = readTextFromUri(u);
                Parsiraj(str);
                adapter1 = new MyArrayAdapterPitanja(this, pitanja);
                lvPitanja.setAdapter(adapter1);
            }catch (Exception e) {
                Toast.makeText(this, "Importovanje kviza nije uspjelo.", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @Override
    public void onBackPressed() {
        Kviz kviz = new Kviz("", pitanja, pomocnaKategorija);
        Intent intent = getIntent();
        intent.putExtra("kviz", kviz);
        setResult(2, intent);
        finish();
    }

    private String readTextFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line+",");
        }
        stringBuilder.append("XXX");
        inputStream.close();
        return stringBuilder.toString();
    }

    private void Parsiraj(String str) {
        pitanja.remove(0);
        adapter1.notifyDataSetChanged();
        try {
            StringTokenizer tokens = new StringTokenizer(str, ",");
            String prvi = tokens.nextToken();
            etnazivKviza.setText(prvi);
            prvi = tokens.nextToken();
            Kategorija k = new Kategorija(prvi, "990");
            int j;
            for (j = 0; j < kategorije.size(); j++) {
                if (kategorije.get(j).getNaziv().equalsIgnoreCase(prvi)) {
                    spinner.setSelection(j);
                    j = kategorije.size() + 2;
                }

            }
            if (j != kategorije.size() + 2) {
                kategorije.add(kategorije.size() - 1, k);
                spinner.setSelection(kategorije.size() - 2);
            }
            prvi = tokens.nextToken();
            int brojPitanja = Integer.parseInt(prvi);


            for(int i=0; i<brojPitanja; i++) {
                prvi = tokens.nextToken();
                String nazivPitanja = prvi;

                prvi = tokens.nextToken();
                int brojOdgovora = Integer.parseInt(prvi);

                prvi = tokens.nextToken();
                int indeksTacnog = Integer.parseInt(prvi);
                ArrayList<String> odgovori = new ArrayList<>();
                for(int r=0; r<brojOdgovora; r++) {

                    prvi = tokens.nextToken();
                    odgovori.add(prvi);
                }
                pitanja.add(pitanja.size()-1, new Pitanje(nazivPitanja, nazivPitanja, odgovori, odgovori.get(indeksTacnog)));
                odgovori = new ArrayList<>();
            }
        } catch (Exception e) {
            new AlertDialog.Builder(this).setMessage("Kviz kojeg importujete je neispravnog formata.").setCancelable(true).create().show();
        }
    }
}
