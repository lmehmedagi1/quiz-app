package ba.unsa.etf.rma.Aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.Klase.Pitanje;
import ba.unsa.etf.rma.R;

public class DodajPitanjeAkt extends AppCompatActivity {
    final ArrayList<String> odgovori = new ArrayList<>();
    Pitanje novoPitanje;
    String tacanOdgovor = "";
    String indeksTacnog;
    EditText et;

    public class UpdateBaze extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String surl = "https://firestore.googleapis.com/v1/projects/spirala3-49671/databases/(default)/documents/Pitanja?access_token=" + TOKEN;
                URL url = new URL(surl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                connection.setDoOutput(true);
                String JsonOutput = "{\"fields\" : { \n \"odgovori\": { \n \"arrayValue\": { \n \"values\": [ \n { \n";
                for(int i=0; i<novoPitanje.getOdgovori().size(); i++) {
                    if(i!=novoPitanje.getOdgovori().size()-1)
                        JsonOutput = JsonOutput + "\"stringValue\": \"" + novoPitanje.getOdgovori().get(i) + "\" \n }, \n { \n";
                    else JsonOutput = JsonOutput + "\"stringValue\": \"" + novoPitanje.getOdgovori().get(i) + "\" \n } \n ] \n } \n }, \n";
                }
                JsonOutput = JsonOutput + "\"naziv\": { \n \"stringValue\": \" " + novoPitanje.getNaziv() + "\" \n }, \n \"indeksTacnog\": {" +
                        "\n \"stringValue\": \"" + indeksTacnog +"\" \n } \n } \n }";

                try(OutputStream os = connection.getOutputStream()) {
                    byte[] input = JsonOutput.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                try(BufferedReader br = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("HELLO", response.toString());
                }


            } catch(Exception e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);

        final ListView lvOdgovori = findViewById(R.id.lvOdgovori);
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.text_view_item, R.id.naziv, odgovori);
        lvOdgovori.setAdapter(adapter);

        final Button btnDodajOdgovor = findViewById(R.id.btnDodajOdgovor);
        final EditText etOdgovor = findViewById(R.id.etOdgovor);
        final EditText nazivPitanja = findViewById(R.id.etNaziv);
        Button btnDodajTacan = findViewById(R.id.btnDodajTacan);
        Button btnDodajPitanje = findViewById(R.id.btnDodajPitanje);

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                odgovori.add(etOdgovor.getText().toString());
                adapter.notifyDataSetChanged();
                etOdgovor.setText("");
            }
        });
        btnDodajTacan.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(tacanOdgovor.isEmpty()) {
                    tacanOdgovor = etOdgovor.getText().toString();
                    indeksTacnog = String.valueOf(odgovori.size());
                    odgovori.add(tacanOdgovor);
                    adapter.notifyDataSetChanged();
                    etOdgovor.setText("");
                }
                else {
                    Toast.makeText(DodajPitanjeAkt.this, "Tačan odgovor vec postoji.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDodajPitanje.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(nazivPitanja.getText().toString().equals("")) {
                    nazivPitanja.setBackgroundColor(Color.RED);
                }
                else if(tacanOdgovor.isEmpty()) {
                    Toast.makeText(DodajPitanjeAkt.this, "Morate unijeti tacan odgovor.", Toast.LENGTH_SHORT).show();
                }
                else {
                    nazivPitanja.setBackgroundColor(Color.TRANSPARENT);
                    novoPitanje = new Pitanje(nazivPitanja.getText().toString(), nazivPitanja.getText().toString(), odgovori, tacanOdgovor);
                    new UpdateBaze().execute();
                    Intent intent = getIntent();
                    intent.putExtra("pitanje", novoPitanje);
                    setResult(1, intent);
                    finish();
                }
            }
        });

        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(odgovori.get(position).equals(tacanOdgovor))
                    tacanOdgovor="";
                odgovori.remove(position);
                adapter.notifyDataSetChanged();
            }
        });
    }


    @Override
    public void onBackPressed() {
        novoPitanje = new Pitanje("", "", odgovori, tacanOdgovor);
        Intent intent = getIntent();
        intent.putExtra("pitanje", novoPitanje);
        setResult(1, intent);
        finish();
    }
}

