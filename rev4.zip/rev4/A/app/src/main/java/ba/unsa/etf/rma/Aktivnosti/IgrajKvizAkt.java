package ba.unsa.etf.rma.Aktivnosti;


import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

import java.util.Calendar;

import ba.unsa.etf.rma.Klase.MyBroadcastReceiver;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.R;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.zavrsiloPitanje {
    PitanjeFrag pitFrag;
    InformacijeFrag infFrag;
    Kviz kviz;
    AlarmManager alarm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        kviz = getIntent().getParcelableExtra("kviz");
        startAlert();
        checkCalendar();

        FragmentManager fm = getSupportFragmentManager();
        FrameLayout informacije = findViewById(R.id.informacijePlace);
        FrameLayout pitanja = findViewById(R.id.pitanjePlace);

        infFrag = (InformacijeFrag) fm.findFragmentById(R.id.informacijePlace);
        pitFrag = (PitanjeFrag) fm.findFragmentById(R.id.pitanjePlace);

        if(infFrag==null) {
            infFrag = new InformacijeFrag();

            Bundle args =new Bundle();
            args.putParcelable("kviz", kviz);
            infFrag.setArguments(args);

            fm.beginTransaction().replace(R.id.informacijePlace, infFrag).commit();
        } else {
            fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        if(pitFrag==null) {
            pitFrag = new PitanjeFrag();

            Bundle args =new Bundle();
            args.putParcelable("kviz", kviz);
            pitFrag.setArguments(args);
            fm.beginTransaction().replace(R.id.pitanjePlace, pitFrag).commit();

        } else {
            fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
    }


    @Override
    public void zavrsiloPitanje(boolean tacan, int i, int tacni) {
        Bundle args = new Bundle();
        if(tacan) {
            args.putInt("tacan", 1);
        } else {
            args.putInt("tacan", 0);
        }
        args.putInt("brojTacnih", tacni);
        args.putInt("i", i);
        infFrag.setArguments(args);
        getSupportFragmentManager().beginTransaction().detach(infFrag).attach(infFrag).commit();
    }

    @Override
    public void onBackPressed() {
        PitanjeFrag.brojTacnih=0;
        PitanjeFrag.i=0;
        super.onBackPressed();
    }
    public void startAlert(){
        int i = Math.round(kviz.getPitanja().size()/(float)2);
        Intent intent = new Intent(this, MyBroadcastReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this.getApplicationContext(), 234324243, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (i * 1000 * 60), pendingIntent);
    }

    public boolean checkCalendar() {
        try {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALENDAR},1);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public void zabraniIgranje(String title) {
        new AlertDialog.Builder(this).setMessage("Uskoro počinje event \"" + title + "\" iz Vašeg kalendara.").setCancelable(true).setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                finish();
            }
        }).create().show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if(requestCode==1) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    final String[] INSTANCE_PROJECTION = new String[]{
                            CalendarContract.Instances.EVENT_ID,
                            CalendarContract.Instances.BEGIN,
                            CalendarContract.Instances.TITLE
                    };

                    final int PROJECTION_ID_INDEX = 0;
                    final int PROJECTION_BEGIN_INDEX = 1;
                    final int PROJECTION_TITLE_INDEX = 2;

                    Calendar beginTime = Calendar.getInstance();
                    beginTime.setTime(Calendar.getInstance().getTime());
                    long startMillis = beginTime.getTimeInMillis();
                    Calendar endTime = Calendar.getInstance();
                    int i = Math.round(kviz.getPitanja().size() / (float) 2);
                    long endMillis = startMillis +  86400000 ; //trazimo samo event-e u narednih 24 sata

                    Cursor cur = null;
                    ContentResolver cr = getContentResolver();

                    Uri.Builder builder = CalendarContract.Instances.CONTENT_URI.buildUpon();
                    ContentUris.appendId(builder, startMillis);
                    ContentUris.appendId(builder, endMillis);

                    cur = cr.query(builder.build(), INSTANCE_PROJECTION, null, null, null);

                    while (cur.moveToNext()) {
                        String title = null;
                        long eventID = 0;
                        long beginVal = 0;

                        eventID = cur.getLong(PROJECTION_ID_INDEX);
                        beginVal = cur.getLong(PROJECTION_BEGIN_INDEX);
                        title = cur.getString(PROJECTION_TITLE_INDEX);

                        if (beginVal-startMillis > 0 && beginVal-startMillis < i*1000*60) {
                            zabraniIgranje(title);
                        }
                    }
                    cur.close();
                }
        }
    }
}
