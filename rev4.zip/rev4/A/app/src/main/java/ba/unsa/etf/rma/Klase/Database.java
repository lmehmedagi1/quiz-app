package ba.unsa.etf.rma.Klase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class Database extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "kvizovi.db";
    public static final String TABLE_KVIZOVI = "kvizovi_tabela";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_NAZIV = "Naziv";
    public static final String COLUMN_ID_KATEGORIJE = "Id_kategorije";
    public static final String COLUMN_PITANJA = "Id_pitanja";
    public static final String TABLE_PITANJA = "pitanja_tabela";
    public static final String COLUMN_TACAN_ODGOVOR = "Tacan_odgovor";
    public static final String COLUMN_ODGOVORI = "Odgovori";
    public static final String TABLE_KATEGORIJE = "Kategorije_tabela";
    public static final String CREATE_TABLE_KVIZOVI = "CREATE TABLE " + TABLE_KVIZOVI
            + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAZIV + " TEXT, "
            + COLUMN_ID_KATEGORIJE + " INTEGER, " + COLUMN_PITANJA + " TEXT)";
    public static final String CREATE_TABLE_PITANJA = "CREATE TABLE " + TABLE_PITANJA
            + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAZIV + " TEXT, "
            + COLUMN_TACAN_ODGOVOR + " TEXT, " + COLUMN_ODGOVORI + " TEXT)";
    public static final String CREATE_TABLE_KATEGORIJE = "CREATE TABLE " + TABLE_KATEGORIJE
            + "(" + COLUMN_ID_KATEGORIJE + " TEXT PRIMARY KEY, " + COLUMN_NAZIV + " TEXT)";


    public Database(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_KVIZOVI);
        db.execSQL(CREATE_TABLE_PITANJA);
        db.execSQL(CREATE_TABLE_KATEGORIJE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_KVIZOVI);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PITANJA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_KATEGORIJE);
        onCreate(db);
    }
    public void drop() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_KVIZOVI);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PITANJA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_KATEGORIJE);
        onCreate(db);
    }

    public boolean dodajKviz(Kviz k) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COLUMN_NAZIV, k.getNaziv());
            values.put(COLUMN_ID_KATEGORIJE, k.getKategorija().getId());
            if(!k.getPitanja().isEmpty()) {
                String pitanja = k.getPitanja().get(0).getNaziv();
                for (int i = 0; i < k.getPitanja().size(); i++) {
                    pitanja = pitanja + "," + k.getPitanja().get(i).getNaziv();
                }
                values.put(COLUMN_PITANJA, pitanja);
            }
            else values.put(COLUMN_PITANJA, "");

            db.insert(TABLE_KVIZOVI, null, values);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean dodajPitanje(Pitanje p) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COLUMN_NAZIV, p.getNaziv());
            values.put(COLUMN_TACAN_ODGOVOR, p.getTacan());
            if (!p.getOdgovori().isEmpty()) {
                String odgovori = p.getOdgovori().get(0);
                for (int i = 0; i < p.getOdgovori().size(); i++) {
                    odgovori = odgovori + "," + p.getOdgovori().get(i);
                }
                values.put(COLUMN_ODGOVORI, odgovori);
            } else values.put(COLUMN_ODGOVORI, "");

            db.insert(TABLE_PITANJA, null, values);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean dodajKategoriju(Kategorija k) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COLUMN_NAZIV, k.getNaziv());
            values.put(COLUMN_ID_KATEGORIJE, k.getId());

            db.insert(TABLE_KATEGORIJE, null, values);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updateKvizove(ArrayList<Kviz> kvizovi) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] koloneRezultat = new String[]{COLUMN_NAZIV};
            for (int i = 0; i < kvizovi.size(); i++) {
                String naziv = kvizovi.get(i).getNaziv();
                String where = COLUMN_NAZIV + "= '" + naziv + "'";
                Cursor c = db.query(TABLE_KVIZOVI, koloneRezultat, where, null, null, null, null);
                if (c.getCount() > 0) {
                    ContentValues values = new ContentValues();
                    values.put(COLUMN_NAZIV, kvizovi.get(i).getNaziv());
                    values.put(COLUMN_ID_KATEGORIJE, kvizovi.get(i).getKategorija().getId());
                    if(!kvizovi.get(i).getPitanja().isEmpty()) {
                        String pitanja = kvizovi.get(i).getPitanja().get(0).getNaziv();
                        for (int k = 0; i < kvizovi.get(i).getPitanja().size(); k++) {
                            pitanja = pitanja + "," + kvizovi.get(i).getPitanja().get(i).getNaziv();
                        }
                        values.put(COLUMN_PITANJA, pitanja);
                    }
                    else values.put(COLUMN_PITANJA, "");
                    continue;
                }
                else { dodajKviz(kvizovi.get(i)); }
                c.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updatePitanja(ArrayList<Pitanje> pitanja) {
        String pitanjaQuery = "SELECT  * FROM " + TABLE_PITANJA;
        ArrayList<String> dbPitanja = new ArrayList<>();
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor c1 = db.rawQuery(pitanjaQuery, null);
            if (c1.moveToFirst()) {
                do {
                    String naziv = c1.getString(c1.getColumnIndex(COLUMN_NAZIV));
                    dbPitanja.add(naziv);
                } while (c1.moveToNext());

                for(int i=0; i<pitanja.size(); i++) {
                    for(int j=0; j<dbPitanja.size(); j++) {
                        if(dbPitanja.get(j).equalsIgnoreCase(pitanja.get(i).getNaziv()))
                            break;
                        else if(j==dbPitanja.size()-1) dodajPitanje(pitanja.get(i));
                    }
                }
            }
            else {
                for(int i=0; i<pitanja.size(); i++) {
                    dodajPitanje(pitanja.get(i));
                }
                c1.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updateKategorije(ArrayList<Kategorija> kategorije) {
        String kategorijeQuery = "SELECT  * FROM " + TABLE_KATEGORIJE;
        ArrayList<String> dbKategorije = new ArrayList<>();
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor c1 = db.rawQuery(kategorijeQuery, null);
            if (c1.moveToFirst()) {
                do {
                    String naziv = c1.getString(c1.getColumnIndex(COLUMN_NAZIV));
                    dbKategorije.add(naziv);
                } while (c1.moveToNext());

                for(int i=0; i<kategorije.size(); i++) {
                    for(int j=0; j<dbKategorije.size(); j++) {
                        if(dbKategorije.get(j).equalsIgnoreCase(kategorije.get(i).getNaziv()))
                            break;
                        else if(j==dbKategorije.size()-1) dodajKategoriju(kategorije.get(i));
                    }
                }
            }
            else {
                for(int i=0; i<kategorije.size(); i++) {
                    dodajKategoriju(kategorije.get(i));
                }
            }
            c1.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updateDatabase(ArrayList<Kviz> kvizovi, ArrayList<Pitanje> pitanja, ArrayList<Kategorija> kategorije) {
        return (updateKvizove(kvizovi) && updatePitanja(pitanja) && updateKategorije(kategorije));
    }

    public ArrayList<Kviz> dohvatiKvizove() {
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_KVIZOVI;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(query, null);
        if(c.moveToFirst()) {
            do {
                try {
                    String naziv = c.getString(c.getColumnIndex(COLUMN_NAZIV));
                    String idKategorije = c.getString(c.getColumnIndex(COLUMN_ID_KATEGORIJE));
                    String pitanja = c.getString(c.getColumnIndex(COLUMN_PITANJA));
                    ArrayList<String> p = parsirajPitanja(pitanja);

                    ArrayList<Pitanje> pitanja1 = new ArrayList<>();
                    for (int i = 0; i < p.size(); i++) {
                        pitanja1.add(dohvatiPitanje(p.get(i)));
                    }
                    Kategorija kat = dohvatiKategoriju(idKategorije);
                    kvizovi.add(new Kviz(naziv, pitanja1, kat));
                } catch (Exception e) {
                    e.printStackTrace();
                    return kvizovi;
                }

            }while(c.moveToNext());
        }
        c.close();
        return kvizovi;
    }

    public ArrayList<Pitanje> dohvatiPitanja() {
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_PITANJA;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(query, null);
        if(c.moveToFirst()) {
            do {
                String naziv = c.getString(c.getColumnIndex(COLUMN_NAZIV));
                String tacan = c.getString(c.getColumnIndex(COLUMN_TACAN_ODGOVOR));
                String x = c.getString(c.getColumnIndex(COLUMN_ODGOVORI));
                ArrayList<String> odgovori = parsirajPitanja(x);
                pitanja.add(new Pitanje(naziv, naziv, odgovori, tacan));
            }while(c.moveToNext());
        }
        c.close();
        return pitanja;
    }

    public ArrayList<Kategorija> dohvatiKategorije() {
        ArrayList<Kategorija> kategorije = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_KATEGORIJE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(query, null);
        if(c.moveToFirst()) {
            do {
                String naziv = c.getString(c.getColumnIndex(COLUMN_NAZIV));
                String id = c.getString(c.getColumnIndex(COLUMN_ID_KATEGORIJE));
                kategorije.add(new Kategorija(naziv, id));
            }while(c.moveToNext());
        }
        c.close();
        return kategorije;
    }

    public Pitanje dohvatiPitanje(String naziv) {
        String query = "SELECT * FROM " + TABLE_PITANJA + "WHERE " + COLUMN_NAZIV + " = " + naziv;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(query, null);
        if(c.moveToFirst()) {
                String tacan = c.getString(c.getColumnIndex(COLUMN_TACAN_ODGOVOR));
                String x = c.getString(c.getColumnIndex(COLUMN_ODGOVORI));
                ArrayList<String> odgovori = parsirajPitanja(x);
                c.close();
                return new Pitanje(naziv, naziv, odgovori, tacan);
        }
        return null;
    }

    public Kategorija dohvatiKategoriju(String id) {
        String query = "SELECT * FROM " + TABLE_KATEGORIJE + "WHERE " + COLUMN_ID_KATEGORIJE + " = " + id;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(query, null);
        if(c.moveToFirst()) {
            String naziv = c.getString(c.getColumnIndex(COLUMN_NAZIV));
            c.close();
            return new Kategorija(naziv, id);
        }
        return null;
    }

    public ArrayList<String> parsirajPitanja(String s) {
        ArrayList<String> pitanja = new ArrayList<>();
        StringTokenizer tokens = new StringTokenizer(s, ",");
        String p;
        while((p = tokens.nextToken())!=null) {
            pitanja.add(p);
        }
        return pitanja;
    }
}