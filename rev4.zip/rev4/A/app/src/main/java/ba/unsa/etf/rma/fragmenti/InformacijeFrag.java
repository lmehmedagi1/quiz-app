package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.R;

public class InformacijeFrag extends Fragment {
    int brojPreostalihPitanja;
    Kviz kviz;
    int i;
    int brojTacnih;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.informacije_frag, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if(getArguments().containsKey("kviz")) {
            kviz = getArguments().getParcelable("kviz");
        }
        TextView nazivKviza = getView().findViewById(R.id.infNazivKviza);
        TextView tvbrojPreostalihPitanja = getView().findViewById(R.id.infBrojPreostalihPitanja);
        TextView tvBrojTacnih = getView().findViewById(R.id.infBrojTacnihPitanja);
        TextView tvProcenatTacni = getView().findViewById(R.id.infProcenatTacni);

        nazivKviza.setText(kviz.getNaziv());
        i = getArguments().getInt("i");
        int brojPitanja = kviz.getPitanja().size();
        brojPreostalihPitanja = brojPitanja - i;
        tvbrojPreostalihPitanja.setText(String.valueOf(brojPreostalihPitanja));

        brojTacnih = getArguments().getInt("brojTacnih");
        tvBrojTacnih.setText(String.valueOf(brojTacnih));
        if(brojTacnih==0 && brojPitanja==brojPreostalihPitanja) {
            String s = "100%";
            tvProcenatTacni.setText(s);
        } else if(brojTacnih==0) tvProcenatTacni.setText("0%");
        else {
            double doSada = (double) brojTacnih / (brojPitanja - brojPreostalihPitanja) * 100;
            String s = String.valueOf(doSada) + "%";
            tvProcenatTacni.setText(s);
        }
        Button btnZavrsiKviz = getView().findViewById(R.id.btnKraj);

        btnZavrsiKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
    }


}
