package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.Aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.Klase.Kategorija;
import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.Klase.MyArrayAdapterKategorija;
import ba.unsa.etf.rma.Klase.MyArrayAdapterKviz;
import ba.unsa.etf.rma.R;

public class ListaFrag extends Fragment {
    ArrayList<Kategorija> kategorije;
    ArrayList<Kviz> kvizovi;
    ListView listaKategorija;
    MyArrayAdapterKategorija adapter;
    private filtrirajKvizove filtrirajKvizove;

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
        return inflater.inflate(R.layout.lista_frag, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        try{
            kategorije = getArguments().getParcelableArrayList("kategorije");
            kvizovi = getArguments().getParcelableArrayList("kvizovi");
            listaKategorija = getView().findViewById(R.id.listaKategorija);

            adapter = new MyArrayAdapterKategorija(getActivity(), kategorije);
            listaKategorija.setAdapter(adapter);

            try {
                filtrirajKvizove = (filtrirajKvizove) getActivity();
            } catch ( ClassCastException e ) {
                throw new ClassCastException(getActivity().toString()+ "Treba implementirati filtrirajKvizove" );
            }

            listaKategorija.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    filtrirajKvizove.filtrirajKvizove(kvizovi, kategorije.get(position).getNaziv(), kategorije);
                }
            });

        } catch(Exception e) {
            Toast.makeText(getContext(), "Nije uspjelo", Toast.LENGTH_SHORT).show();
        }
    }

    public interface filtrirajKvizove {
        public void filtrirajKvizove(ArrayList<Kviz> kvizovi, String kategorija, ArrayList<Kategorija> kategorije);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        adapter.notifyDataSetChanged();
        Toast.makeText(getActivity(), "HHHHHHHHHH", Toast.LENGTH_SHORT).show();
    }

    public void updateListu() {
        adapter.notifyDataSetChanged();
    }
}
