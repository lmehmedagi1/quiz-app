package ba.unsa.etf.rma.fragmenti;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizAdapter;
import ba.unsa.etf.rma.klase.KvizAdapter2;
import ba.unsa.etf.rma.klase.Pitanje;

public class ListaFrag extends Fragment {
    private ListView listaKategorija;
    private ArrayList<Kategorija> sveKategorije = new ArrayList<>();
    private KategorijeAdapter adapterKategorije;
    private PressListView press;

    public interface PressListView {
        public void pressLV(ArrayList<Kviz> k);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista, container, false);
        listaKategorija = (ListView) view.findViewById(R.id.listaKategorija);
        sveKategorije = (ArrayList<Kategorija>) getArguments().getSerializable("sveKategorije");
        Resources res = getResources();
        adapterKategorije = new KategorijeAdapter(getActivity(), sveKategorije, res);
        listaKategorija.setAdapter(adapterKategorije);
        try {
            press = (PressListView) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString());
        }
        listaKategorija.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (KvizoviAkt.kategorije.get(position).getNaziv().equals("Svi")) {
                    KvizoviAkt.filtrirano2 = false;
                    press.pressLV(KvizoviAkt.kvizovi);
                } else {
                    KvizoviAkt.filtrirano2 = true;
                    KvizoviAkt.filterKvizovi2 = new ArrayList<Kviz>();
                    for (int i = 0; i < KvizoviAkt.kvizovi.size() - 1; i++) {
                        if (KvizoviAkt.kvizovi.get(i).getKategorija().getNaziv().equals(KvizoviAkt.kategorije.get(position).getNaziv())) {
                            KvizoviAkt.filterKvizovi2.add(KvizoviAkt.kvizovi.get(i));
                        }
                    }
                    KvizoviAkt.filterKvizovi2.add(new Kviz("Dodaj kviz"));
                    press.pressLV(KvizoviAkt.filterKvizovi2);
                }
            }
        });
        return view;
    }
}
