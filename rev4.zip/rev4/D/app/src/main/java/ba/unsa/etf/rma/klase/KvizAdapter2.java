package ba.unsa.etf.rma.klase;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class KvizAdapter2 extends BaseAdapter implements View.OnClickListener{
    private Activity activity;
    private ArrayList kvizovi;
    private static LayoutInflater inflater = null;
    public Resources res;
    Kviz kviz = null;
    int i = 0;

    @Override
    public void onClick(View v) {
    }

    public static class ViewHolder {
        public TextView naziv;
        public IconView ikona;
        public TextView pitanja;
    }

    public KvizAdapter2(Activity activity, ArrayList data, Resources res) {
        this.activity = activity;
        this.kvizovi = data;
        this.res = res;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        if (kvizovi.size() <= 0)
            return 1;
        return kvizovi.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        KvizAdapter2.ViewHolder holder;
        if (convertView == null) {
            v = inflater.inflate(R.layout.element_gridview, null);
            holder = new KvizAdapter2.ViewHolder();
            holder.naziv = (TextView) v.findViewById(R.id.Itemname);
            holder.ikona = (IconView) v.findViewById(R.id.icon);
            holder.pitanja = (TextView) v.findViewById(R.id.brojPitanja);
            v.setTag(holder);
        } else {
            holder = (KvizAdapter2.ViewHolder) v.getTag();
        }
        if (kvizovi.size() <= 0) {
            holder.naziv.setText(R.string.nema_info);
            holder.pitanja.setText(R.string.nema_info);
            holder.ikona.setImageResource(0);
        } else {
            kviz = (Kviz) kvizovi.get(position);
            holder.naziv.setText(kviz.getNaziv());
            holder.pitanja.setText(String.valueOf(kviz.getPitanja().size() - 1));
            if (kvizovi.size() - 1 == position) {
                holder.ikona.setImageResource(R.drawable.plus);
                holder.pitanja.setText("");
            } else {
                holder.ikona.setImageResource(0);
                if (kviz.getKategorija().getId().length() == 0) {
                    holder.ikona.setImageResource(R.drawable.slika);
                    //holder.ikona.setIcon(Integer.parseInt("26"));
                } else holder.ikona.setIcon(Integer.parseInt(kviz.getKategorija().getId()));
            }
            //holder.ikona.setImageResource(Integer.parseInt(kviz.getKategorija().getId()));
            //v.setOnClickListener(new AdapterView.OnItemClickListener(position));
        }
        return v;
    }
}
